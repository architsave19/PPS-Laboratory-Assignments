#include <stdio.h>

int main(){
	int age = 18;
	if (age >=18){
		printf("You can vote.\n");
	}
	return 0;
}
