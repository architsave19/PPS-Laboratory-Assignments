#include <stdio.h>

int main() {
	int age = 20;
	if (age >= 18) {
		if (age >= 21) {
			printf("You can drink.\n");
		}
		else {
		printf("You can drink, but cannot vote.\n");
		}
	}
	return 0;
}
