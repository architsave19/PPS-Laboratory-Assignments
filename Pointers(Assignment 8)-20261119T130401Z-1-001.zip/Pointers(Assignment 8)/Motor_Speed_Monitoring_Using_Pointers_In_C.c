#include <stdio.h>

void swap(int *a, int *b) {
	int temp = *a;
	*a = *b;
	*b = temp;
	
}

int main() {
	int motor1, motor2;
	int *p1, *p2;
	
	printf("Enter speed of Motor 1 (RPM): ");
	scanf("%d", &motor1);

	printf("Enter speed of Motor 2 (RPM): ");
	scanf("%d", &motor2);

	
	p1 = &motor1;
	p2 = &motor2;
	
	printf("\nBefore Swapping:\n");
	printf("Motor 1 Speed : %d RPM (Address: %p)\n", motor1, (void*)p1);
	printf("Motor 2 Speed : %d RPM (Address: %p)\n", motor2, (void*)p2);
	
	swap(p1, p2);
	
	printf("\nAfter Swapping (Control Swapped):\n");
	printf("Motor 1 Speed: %d RPM (Address: %p)\n", motor1,  (void*)p1);
	printf("Motor 2 Speed: %d RPM (Address: %p)\n", motor2,  (void*)p2);
	
	return 0;
	
}
	
