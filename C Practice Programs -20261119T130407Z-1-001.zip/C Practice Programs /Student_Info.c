#include <stdio.h>
int main(){
	printf("Student Introduction\n");
	printf("Student Name: Sanay Gupta\n");
	printf("Division: FY 22 - MECH\n");
	return 0;
}
