#include <stdio.h>

int main(){
	printf("C:\\Programs||C");
	return 0;
}
