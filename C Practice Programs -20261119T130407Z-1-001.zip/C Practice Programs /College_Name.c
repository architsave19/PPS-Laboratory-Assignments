#include <stdio.h>
int main(){
	printf("My College Name is MIT WPU, Kothrud, Pune");
	return 0;
}
