#include <stdio.h>

int main(){
	printf("Name: \tSanay Gupta");
	return 0;
}
