#include <stdio.h>

int main(){
	printf("Red\nGreen\nBlue");
	return 0;
}
