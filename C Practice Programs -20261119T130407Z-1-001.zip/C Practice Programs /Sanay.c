#include <stdio.h>
int main(){
	printf("My name is Sanay Gupta");
	return 0;
}
