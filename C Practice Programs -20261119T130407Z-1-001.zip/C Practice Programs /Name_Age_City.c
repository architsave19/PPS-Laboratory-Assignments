#include<stdio.h>
int main(){
	printf("Name : Sanay Gupta\n");
	printf("Age: 21\n");
	printf("City: Pune\n");
	return 0;
}
